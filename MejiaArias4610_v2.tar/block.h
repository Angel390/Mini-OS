/*
Angel Mejia
CSE 4610

block.h
Contains the header file for the block program
*/

#ifndef BLOCK_H
#define BLOCK_H

#include "sdisk.h"

vector<string> block(string buffer, int b);

#endif